const CACHE='de-che-5a6952db5791';
const ASSETS=["/","/assets/index-dazSNd8i.css","/assets/index-f-rtvJCO.js","/favicon.svg","/illustrations/chip.svg","/illustrations/crisis.svg","/illustrations/empire.svg","/illustrations/factory.svg","/illustrations/meeting.svg","/illustrations/servers.svg","/illustrations/shop.svg","/index.html","/manifest.webmanifest"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('de-che-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('message',event=>{if(event.data==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
 if(event.request.mode==='navigate'){event.respondWith(caches.open(CACHE).then(cache=>cache.match('/index.html',{ignoreVary:true})).then(cached=>cached||fetch(event.request)));return;}
 event.respondWith(caches.open(CACHE).then(cache=>cache.match(event.request,{ignoreVary:true})).then(cached=>cached||fetch(event.request)));
});
